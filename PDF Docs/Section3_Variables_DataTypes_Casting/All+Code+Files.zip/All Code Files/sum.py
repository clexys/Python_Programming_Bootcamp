def get_sum(*args):
    sum_1 = 0
    for i in args:
        sum_1 += i
    return sum_1
